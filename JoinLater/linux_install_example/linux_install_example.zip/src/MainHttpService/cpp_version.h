// cpp_version.h
#ifndef CPP_VERSION_HPP
#define CPP_VERSION_HPP

#if defined(__clang__) || defined(__GNUC__)

#define CPP_STANDARD __cplusplus

#elif defined(_MSC_VER)

#define CPP_VERSION _MSVC_LANG

#endif

#if CPP_VERSION >= 199711L
#define HAS_CPP_03 true
#endif

#if CPP_VERSION >= 201103L
#define HAS_CPP_11 true
#endif

#if CPP_VERSION >= 201402L
#define HAS_CPP_14 true
#endif

#if CPP_VERSION >= 201703L
#define HAS_CPP_17 true
#endif

#endif      //CPP_VERSION_HPP