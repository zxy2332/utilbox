cd ..
# 构建工程命令
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX:PATH=install -DBuildTest=ON -G 'CodeBlocks - Unix Makefiles' -S ./ -B ./build
# 执行编译命令
cmake --build ./build/ --target install -- -j 10
